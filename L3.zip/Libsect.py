# 1. Los experimentos de la canicas con coeficiente booleanos.

def multiplicar_matrices(m1, m2):
    if len(m1[0]) == len(m2):
        m3 = []
        for i in range(len(m1)):
            m3.append([])
            for j in range(len(m2[0])):
                m3[i].append(0)

        for i in range(len(m1)):
            for j in range(len(m2[0])):
                for k in range(len(m1[0])):
                    m3[i][j] += m1[i][k] * m2[k][j]
        return m3
    else:
        return None


# c = multiplicar_matrices(a, b)
#
# if c == None:
#     print('No se pueden multiplicar')
# else:
#     for fila in c:
#         print("[", end=" ")
#         for elemento in fila:
#             print(elemento, end=" ")
#         print("]")

# def multiplicar_matrices_n(m1,n):
#     m3 = []
#     for i in range(n):
#         m3 += lct.ProdMtx(m1, m1)
#     if n != 1:
#         res = lct.ProdMtx(m1, m1)
#     else:
#         res = lct.ProdMtx(m1, m1)
#     return res


# 2. Experimentos de las múltiples rendijas clásico probabilístico, con más de dos rendijas.

def multiplicar_matrices_fr(m1, m2):
    if len(m1[0]) == len(m2):
        m3 = []
        for i in range(len(m1)):
            m3.append([])
            for j in range(len(m2[0])):
                m3[i].append(0)

        for i in range(len(m1)):
            for j in range(len(m2[0])):
                for k in range(len(m1[0])):
                    m3[i][j] += m1[i][k] * m2[k][j]
        return m3
    else:
        return None


def multiplicar_matrices_pr(m1, m2):
    if len(m1[0]) == len(m2):
        m3 = []
        for i in range(len(m1)):
            m3.append([])
            for j in range(len(m2[0])):
                m3[i].append(0)

        for i in range(len(m1)):
            for j in range(len(m2[0])):
                for k in range(len(m1[0])):
                    m3[i][j] += m1[i][k] * m2[k][j]
        return m3
    else:
        return None

# 3. Experimento de las múltiples rendijas cuántico.
def multiplicar_matrices_cplx(m1, m2):
    if len(m1[0]) == len(m2):
        m3 = []
        for i in range(len(m1)):
            m3.append([])
            for j in range(len(m2[0])):
                m3[i].append(0)

        for i in range(len(m1)):
            for j in range(len(m2[0])):
                for k in range(len(m1[0])):
                    m3[i][j] += lc.cplxproduct(m1[i][k], m2[k][j])
        return m3
    else:
        return None

# 4. Cree una función para graficar con un diagrama de barras que muestre las probabilidades de un vector de estados. La imagen se debe poder guardar en el computador con un formato de imagen.
